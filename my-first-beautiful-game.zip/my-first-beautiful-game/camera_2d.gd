extends Camera2D


@export var ref: Node2D

func _process(_delta: float) -> void:
	global_position = ref.global_position
